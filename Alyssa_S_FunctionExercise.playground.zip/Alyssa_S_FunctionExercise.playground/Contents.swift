import UIKit

func calc(inputOne: Int, inputTwo: Int) -> Int {
    return inputOne * inputTwo
}
print(calc(inputOne: 2, inputTwo: 3))
print(calc(inputOne: 24, inputTwo: 33))
